<?php
/**
 *  @package     AkeebaStrapper
 *  @copyright   Copyright (c)2010-2014 Nicholas K. Dionysopoulos
 *  @license     GNU General Public License version 2, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die;

define('AKEEBASTRAPPER_VERSION', '2.3.0');
define('AKEEBASTRAPPER_DATE', '2014-05-02 19:14:41');
define('AKEEBASTRAPPER_MEDIATAG', md5(AKEEBASTRAPPER_VERSION . AKEEBASTRAPPER_DATE));